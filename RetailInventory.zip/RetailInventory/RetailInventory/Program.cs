﻿using RetailInventory.Data;
using RetailInventory.Models;

class Program
{
    static void Main()
    {
        using var context = new AppDbContext();

        // Add a category
        var electronics = new Category { Name = "Electronics" };
        context.Categories.Add(electronics);

        // Add a product
        var phone = new Product
        {
            Name = "Smartphone",
            StockLevel = 50,
            Category = electronics
        };
        context.Products.Add(phone);

        context.SaveChanges();

        Console.WriteLine("Data saved!");
    }
}
