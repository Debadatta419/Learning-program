﻿using System;

class Program
{
    static void Main()
    {
        double presentValue = 1000.0; // Example: $1000 initial investment
        double growthRate = 0.05;     // 5% growth rate
        int periods = 10;             // Forecast over 10 periods (e.g., years)

        double futureValue = CalculateFutureValueRecursive(presentValue, growthRate, periods);
        Console.WriteLine($"Future Value after {periods} periods: {futureValue:F2}");
    }

    // Recursive method
    public static double CalculateFutureValueRecursive(double value, double growthRate, int periods)
    {
        if (periods == 0)
            return value; // Base case: no more periods

        return CalculateFutureValueRecursive(value * (1 + growthRate), growthRate, periods - 1);
    }
}
