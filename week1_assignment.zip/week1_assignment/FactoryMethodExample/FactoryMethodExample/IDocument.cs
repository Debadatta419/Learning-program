﻿// IDocument.cs
public interface IDocument
{
    void Open();
}

