﻿using System;

namespace SingletonPatternExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger logger1 = Logger.GetInstance();
            Logger logger2 = Logger.GetInstance();

            logger1.Log("First log message.");
            logger2.Log("Second log message.");

            Console.WriteLine($"Are logger1 and logger2 the same instance? {ReferenceEquals(logger1, logger2)}");
        }
    }
}