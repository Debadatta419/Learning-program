﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        // Step 1: Create products
        Product[] products = new Product[]
        {
            new Product(101, "Laptop", "Electronics"),
            new Product(205, "Phone", "Electronics"),
            new Product(150, "Shoes", "Footwear"),
            new Product(300, "Watch", "Accessories")
        };

        // Step 2: Linear search (no sorting needed)
        Product resultLinear = LinearSearch(products, 150);
        Console.WriteLine("Linear Search Result: " + (resultLinear != null ? resultLinear.ToString() : "Not Found"));

        // Step 3: Binary search (sort first)
        Product[] sortedProducts = products.OrderBy(p => p.ProductId).ToArray();
        Product resultBinary = BinarySearch(sortedProducts, 150);
        Console.WriteLine("Binary Search Result: " + (resultBinary != null ? resultBinary.ToString() : "Not Found"));
    }

    public static Product LinearSearch(Product[] products, int targetId)
    {
        foreach (Product product in products)
        {
            if (product.ProductId == targetId)
                return product;
        }
        return null;
    }

    public static Product BinarySearch(Product[] products, int targetId)
    {
        int low = 0, high = products.Length - 1;

        while (low <= high)
        {
            int mid = low + (high - low) / 2;
            if (products[mid].ProductId == targetId)
                return products[mid];
            else if (products[mid].ProductId < targetId)
                low = mid + 1;
            else
                high = mid - 1;
        }

        return null;
    }
}

